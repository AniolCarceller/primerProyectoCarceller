<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Si</title>
</head>
<body>
    <?php
        include_once("productos/listado.php");

        $vista;
    ?>
</body>
</html>