<?php

define("default_action", "index");

define("url", "http://127.0.0.1/DAW2/Proyecto1/");